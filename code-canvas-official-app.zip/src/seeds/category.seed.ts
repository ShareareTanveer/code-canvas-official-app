export const categorySeed = [
    {
      id:1,
      name: 'Management',
    },
    {
      id:2,
      name: 'Ecommerce',
    },
  ];
  
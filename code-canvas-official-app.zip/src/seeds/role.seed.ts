export const roleSeed = [
  {
    id:1,
    name: 'Admin',
  },
  {
    id:2,
    name: 'User',
  },
];

export const tagSeed = [
    {
      id:1,
      name: 'employee Management',
    },
    {
      id:2,
      name: 'Ecommerce Website',
    },
  ];
  
export default {
  COOKIE_USER: 'user',
  KEY_USER_ID: 'userId',
  COOKIE_RESET_PASSWORD: 'pending_user',
  COOKIE_REGISTER_USER: 'registered_user',
  KEY_USER_EMAIL: 'email',
  COOKIE_OTP_EMAIL: 'otpEmail',
  COOKIE_OTP: 'otp',
};

export default {
  DUPLICATED: 'ER_DUP_ENTRY',
};

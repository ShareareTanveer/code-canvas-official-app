export default {
  USER: 'User',
  ADMIN: 'Admin',
};

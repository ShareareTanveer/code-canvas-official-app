export interface IOurServiceImageResponse {
  id: number;
  image: string;
}

export interface ICreateOurServiceImage {
  image: string;
}

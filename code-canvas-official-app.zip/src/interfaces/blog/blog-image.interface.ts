export interface IBlogImageResponse {
  id: number;
  image: string;
}

export interface ICreateBlogImage {
  image: string;
}

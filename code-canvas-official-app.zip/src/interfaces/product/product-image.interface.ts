export interface IProductImageResponse {
  id: number;
  image: string;
}

export enum Estatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
}

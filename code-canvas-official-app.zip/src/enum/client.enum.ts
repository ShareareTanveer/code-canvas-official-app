export enum EClientType {
  INDIVIVUAL = 'INDIVIVUAL',
  CORPORATE = 'CORPORATE',
}

export enum EWalkingCustomerType {
  YES = 'YES',
  NO = 'NO',
}

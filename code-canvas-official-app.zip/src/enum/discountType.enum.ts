export enum EDiscountType {
    PERCENT = 'Percent',
    AMOUNT = 'Amount',
  }
  
export enum EOpeningBalanceType {
  DUE = 'DUE',
  ADVANCE = 'ADVANCE',
}

export enum EGroupType {
  HAJJ = 'HAJJ',
  UMRAH = 'UMRAH',
}

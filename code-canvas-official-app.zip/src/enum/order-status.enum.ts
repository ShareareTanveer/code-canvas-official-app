export enum EOrderStaus {
    Pending = 'Pending',
    Paid = 'Paid',
    Confirmed = 'Confirmed',
  }
  
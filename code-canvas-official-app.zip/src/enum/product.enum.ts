export enum EProductCategory {
  HAJJ = 'HAJJ',
  AIR_TICKET = 'AIR_TICKET',
  TOUR_PACKAGE = 'TOUR_PACKAGE',
  UMRAH = 'UMRAH',
  VISA = 'VISA',
  OTHER = 'OTHER',
}

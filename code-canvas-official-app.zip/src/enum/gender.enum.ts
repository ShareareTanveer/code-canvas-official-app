export enum EGender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other',
}
